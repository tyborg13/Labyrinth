from pathlib import Path
import json,math,statistics
out=Path('/tmp/remaining-hitches-20261007')
def stats(values):
 values=sorted(values);n=len(values)
 if not n:return {}
 return {'samples':n,'mean':sum(values)/n,'over_20':sum(x>20.0 for x in values),'median':values[max(0,math.ceil(n*.5)-1)],'p95':values[max(0,math.ceil(n*.95)-1)],'p99':values[max(0,math.ceil(n*.99)-1)],'max':values[-1],'over_16_67':sum(x>16.67 for x in values),'over_33_33':sum(x>33.33 for x in values)}
reports={(variant,repeat):json.loads((out/f'final-all-{variant}-{repeat}.json').read_text()) for variant in ['base','candidate'] for repeat in range(2)}
runs=[];phase_names=None;semantic_differences=[]
for (variant,repeat),r in reports.items():
 result=r['result'];phases=result['phases']
 if phase_names is None:phase_names=set(phases)
 assert set(phases)==phase_names
 values=[x for p in phases.values() for x in p['raw_frame_intervals_ms']]
 runs.append({'variant':variant,'repeat':repeat,'valid':r['returncode']==0 and not r['engine_errors'] and not result['semantic_errors'] and not result['unfocused_observations'] and result['orphan_nodes']==0 and r['runtime_sources']==r['runtime_sources_after'],'phase_count':len(phases),'pooled_phase_frames':stats(values),'static_memory_bytes':result['static_memory_bytes'],'public_startup':{k:{t:v[t] for t in ['frame_interval_ms','completion_ms','sample_count','frames_over_16_67_ms','frames_over_33_33_ms'] if t in v} for k,v in result.get('public_startup',{}).items() if isinstance(v,dict)}})
comparison={}
for key in sorted(phase_names):
 row={}
 for variant in ['base','candidate']:
  phases=[reports[(variant,i)]['result']['phases'][key] for i in range(2)]
  row[variant]={'pooled':stats([x for p in phases for x in p['raw_frame_intervals_ms']]),'individual_stats':[p['frame_interval_ms'] for p in phases],'handler_ms':[p.get('handler_ms') for p in phases],'over_33_33':[p['frames_over_33_33_ms'] for p in phases]}
 semantics=[reports[(v,i)]['result']['phases'][key].get('semantics') for v in ['base','candidate'] for i in range(2)]
 if any(s!=semantics[0] for s in semantics[1:]):semantic_differences.append({'phase':key,'values':semantics})
 comparison[key]=row
summary={'method':'Nearest-rank percentiles, complete raw RenderingServer.frame_post_draw phase windows; public startup separately reported; paired phase maxima are not statistical FPS estimates.','runs':runs,'phase_comparison':comparison,'semantic_differences':semantic_differences}
(out/'final-all-measurements.json').write_text(json.dumps(summary,indent=2))
print('RUNS',json.dumps(runs,indent=2));print('SEMANTIC_DIFFERENCES',len(semantic_differences))
for key,row in comparison.items():
 if max(row['base']['pooled']['max'],row['candidate']['pooled']['max'])>33.33 or key in ['character/open','grimoire/open_all_known','reward_skill/reroll','travel/combat/begin']:
  print(key,'BASE',row['base']['individual_stats'],'CANDIDATE',row['candidate']['individual_stats'],'>33',row['base']['over_33_33'],'->',row['candidate']['over_33_33'])
