from pathlib import Path
import json,math
out=Path('/tmp/remaining-hitches-20261007')
def stats(xs):
 a=sorted(xs);n=len(a)
 return {'samples':n,'mean':sum(a)/n,'over_20':sum(x>20.0 for x in a),'median':a[max(0,math.ceil(n*.5)-1)],'p95':a[max(0,math.ceil(n*.95)-1)],'p99':a[max(0,math.ceil(n*.99)-1)],'max':a[-1],'over_16_67':sum(x>16.67 for x in a),'over_33_33':sum(x>33.33 for x in a)} if a else {}
rs={v:json.loads((out/f'final-runtime-{v}.json').read_text()) for v in ['base','candidate']}
summary={'source_binding':'final-source-binding.json','method':'Complete paired native runtime capture, one pair; leaf phase raw completed-draw frames only, duration/combined reports kept separate. Do not infer repeatable small tail changes from one pair.','runs':{},'phases':{},'reference_digests_match':rs['base']['result']['enemy_round_digests']==rs['candidate']['result']['enemy_round_digests']}
for v,raw in rs.items():
 r=raw['result'];summary['runs'][v]={'valid':not raw['engine_errors'] and not r['semantic_errors'] and r['probe_unfocused_observations']==0 and r['final_orphan_nodes']==0 and raw['runtime_sources']==raw['runtime_sources_after'],'static_memory_bytes':r['static_memory_bytes'],'initial_nodes':r['initial_nodes'],'final_nodes':r['final_nodes'],'repeated_install_nodes':r['repeated_install_nodes'],'final_orphan_nodes':r['final_orphan_nodes'],'invalid_render_texture_memory_monitor':r['render_texture_memory_bytes']==2**63-1,'lanes':{k:len(r[k]) for k in ['action_matrix','ability_action_matrix','enemy_round_matrix','interaction_matrix','composition_matrix','umbra_stage_matrix']}}
for lane in ['idle','cold_interaction','startup_prewarm_idle','movement_pool_action','action_matrix','ability_action_matrix','enemy_round_matrix','interaction_matrix','composition_matrix','umbra_stage_matrix','blink_preview_workload','live_save_blink_workload']:
 for v in rs:
  def walk(node,path):
   if not isinstance(node,dict):return
   if 'raw_frame_intervals_ms' in node:summary['phases'].setdefault(path,{})[v]=stats(node['raw_frame_intervals_ms'])
   for k,n in node.items():
    if isinstance(n,dict):walk(n,path+'/'+k)
  walk(rs[v]['result'][lane],lane)
for lane in ['action_matrix','ability_action_matrix','enemy_round_matrix']:
 summary['phases'][lane+'/combined_sampled_frames']={v:stats([x for p in rs[v]['result'][lane].values() for x in p['raw_frame_intervals_ms']]) for v in rs}
(out/'final-runtime-measurements.json').write_text(json.dumps(summary,indent=2))
print('RUNS',json.dumps(summary['runs'],indent=2));print('DIGEST_EQUAL',summary['reference_digests_match'])
for k,row in summary['phases'].items():
 if k.startswith(('enemy_round_matrix/','action_matrix/','ability_action_matrix/','idle','blink_preview_workload/','live_save_blink_workload/')):print(k,json.dumps(row))
