from pathlib import Path
import json, subprocess, os, sys, time, hashlib
from collections import Counter
root=Path('/Users/borgerding/workspace/Labyrinth.worktrees/isolate-card-completion-stalls')
out=Path('/tmp/remaining-hitches-20261007')
old=root/'spec/proofs/performance-2026-10-06'
sys.path.insert(0,str(root/'tools'))
from card_completion_stall import runtime_hashes

def sources():
 d=runtime_hashes(root)
 for folder in ['tests','tools']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.gd','.py']:d[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
 d['external-native-window-launcher']=hashlib.sha256((out/'godot_windowed_1920.sh').read_bytes()).hexdigest()
 return d
binding=sources()
(out/'source-binding.json').write_text(json.dumps({'base':'b792d218c281181eb2fa20aa853bdad1ca242305','candidate_runtime_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'runtime_test_tool_sources':binding},indent=2))
binding_hash=hashlib.sha256(json.dumps(binding,sort_keys=True).encode()).hexdigest()
def execute(name, command, expected_errors):
 assert sources()==binding,'Source changed before '+name
 print('START',name,flush=True)
 env={k:v for k,v in os.environ.items() if not k.startswith(('LABYRINTH_RUNTIME_PERF_','LABYRINTH_STALL_','LABYRINTH_COMBAT_'))}
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 lines=(out/(name+'.log')).read_text().splitlines()
 errors=[l for l in lines if l.startswith(('ERROR:','SCRIPT ERROR:'))]
 unexpected=list((Counter(errors)-Counter(expected_errors)).elements())
 missing=list((Counter(expected_errors)-Counter(errors)).elements())
 result={'name':name,'command':command,'returncode':r.returncode,'seconds':time.monotonic()-start,'source_binding_sha256':binding_hash,'source_before_after_equal':sources()==binding,'expected_error_lines':expected_errors,'engine_errors':errors,'unexpected_error_lines':unexpected,'missing_expected_error_lines':missing,'result_lines':[l for l in lines if 'RESULT' in l or l.startswith(('PASS','FAIL'))]}
 (out/(name+'.json')).write_text(json.dumps(result,indent=2))
 print('FINISH',name,'rc',r.returncode,'seconds',round(result['seconds'],1),flush=True)
 if r.returncode or unexpected or missing or not result['source_before_after_equal']:raise RuntimeError('Failed '+name)
 return result
focused=json.loads((old/'final-focused-summary.json').read_text())
reports=[]
for d in focused:
 script=d['name'].removeprefix('final-')
 name='focused-'+script
 command=[sys.executable,'tools/godot_task_runner.py','--task-id','isolate-card-completion-stalls-'+name,'--stream','--','godot','--headless','--path','.','--script','tests/'+script+'.gd']
 reports.append(execute(name,command,d.get('expected_error_lines',[])))
(out/'focused-summary.json').write_text(json.dumps(reports,indent=2))
native=json.loads((old/'final-native-quality-summary.json').read_text())
reports=[]
for script, expected in [(d['name'].split('native-',1)[-1].split('native2-',1)[-1],d.get('expected_error_lines',[])) for d in native]+[('objective_glyph_equivalence_test',[]),('retained_character_loadout_equivalence_test',[])]:
 name='native-'+script
 command=[sys.executable,'tools/visual_probe_runner.py','tests/'+script+'.gd','--godot',str(out/'godot_windowed_1920.sh'),'--task-id','isolate-card-completion-stalls-'+name,'--no-headless','--display-driver','macos','--audio-driver','Dummy','--rendering-method','mobile','--rendering-driver','metal','--timeout','120','--startup-timeout','12','--min-images','0','--result-manifest',str(out/(name+'.manifest.json'))]
 if script not in ['deferred_skill_analytics_test','deferred_run_skill_analytics_test','retained_character_loadout_equivalence_test']:command+=['--expect-size','1920x1080']
 reports.append(execute(name,command,expected))
 manifest=json.loads((out/(name+'.manifest.json')).read_text());assert manifest['ok']
(out/'native-summary.json').write_text(json.dumps(reports,indent=2))
print('ALL VERIFICATION PASSED',flush=True)
