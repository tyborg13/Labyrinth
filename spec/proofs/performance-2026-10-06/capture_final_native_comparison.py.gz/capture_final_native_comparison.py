from pathlib import Path
import subprocess, os, json, time, sys, hashlib
root = Path('/Users/borgerding/workspace/Labyrinth.worktrees/isolate-card-completion-stalls')
out = Path('/tmp/remaining-hitches-20261004')
sys.path.insert(0, str(root/'tools'))
from card_completion_stall import runtime_hashes
def source_hashes():
    result=runtime_hashes(root)
    for folder in ['tests', 'tools']:
        for path in sorted((root/folder).rglob('*')):
            if path.is_file() and path.suffix in ['.gd','.py']:
                result[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
    wrapper=out/"godot_windowed_1920.sh"
    result["external-native-window-launcher"]=hashlib.sha256(wrapper.read_bytes()).hexdigest()
    return result
source_binding = None
def run(name, command, settings, marker=None):
    env={k:v for k,v in os.environ.items() if not k.startswith(('LABYRINTH_RUNTIME_PERF_', 'LABYRINTH_STALL_', 'LABYRINTH_COMBAT_'))}
    env.update(LABYRINTH_RUNTIME_PERF_CAPPED_HAND='1', LABYRINTH_RUNTIME_PERF_HAND_POINTER='1', LABYRINTH_RUNTIME_PERF_REDUCED_MOTION='0', LABYRINTH_RUNTIME_PERF_VIEWPORT_SIZE='1920x1080')
    env.update(settings)
    source_binding = source_hashes()
    started=time.monotonic()
    print('START',name,flush=True)
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    report={'name':name,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':command,'settings':{k:v for k,v in env.items() if k.startswith('LABYRINTH_')},'returncode':p.returncode,'duration':time.monotonic()-started,'runtime_sources':source_binding,'runtime_sources_after':source_hashes()}
    if marker:
        for line in (out/(name+'.log')).read_text().splitlines():
            if marker in line:
                payload=line.split(marker,1)[1].strip()
                if payload.startswith('FAIL '): payload=payload[5:]
                try: report['result']=json.loads(payload)
                except Exception as e: report['parse_error']=str(e)
        (out/(name+'.json')).write_text(json.dumps(report))
    report['engine_errors']=[line for line in (out/(name+'.log')).read_text().splitlines() if line.startswith(('SCRIPT ERROR:', 'ERROR:'))]
    (out/(name+'.json')).write_text(json.dumps(report))
    print('FINISH',name,'rc',p.returncode,'seconds',round(report['duration'],1),flush=True)
    result=report.get('result', {})
    geometries=[geometry for phase in result.get('phases',{}).values() for geometry in phase.get('window_geometries',[])]
    if p.returncode or report['engine_errors'] or not result or result.get('semantic_errors') or result.get('unfocused_observations') or result.get('probe_unfocused_observations') or result.get('final_orphan_nodes') or result.get('orphan_nodes') or report['runtime_sources'] != report['runtime_sources_after']:
        raise RuntimeError('Invalid native capture: '+name)
    if result.get('viewport') != '1920x1080': raise RuntimeError('Wrong viewport '+name)
    if result.get('probe_actual_window_size') and (result['probe_actual_window_size'] != '(1920, 1080)' or result.get('probe_window_mode') != 'windowed'): raise RuntimeError('Wrong full native window '+name)
    if any(g.get('root_size') != '(1920, 1080)' or g.get('native_size') != '(1920, 1080)' or g.get('mode') != 0 or g.get('ui_scale') != 1.0 for g in geometries):
        raise RuntimeError('Invalid native geometry: '+name)



base=subprocess.check_output(['git','rev-parse','origin/master'],cwd=root,text=True).strip()
paths=[p for p in subprocess.check_output(['git','diff','--diff-filter=M','origin/master','--name-only','--','scripts','scenes','shaders','data','themes','addons','fonts','assets','project.godot'],cwd=root,text=True).splitlines() if (root/p).is_file()]
current={p:(root/p).read_bytes() for p in paths}
original={p:subprocess.check_output(['git','show',base+':'+p],cwd=root) for p in paths}
(out/'final-measured-candidate-runtime.json').write_text(json.dumps({'worktree_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'base':base,'sources':{p:hashlib.sha256(v).hexdigest() for p,v in current.items()}},indent=2))
try:
 for variant,index in [('base',0),('candidate',0),('candidate',1),('base',1)]:
  for path,data in (original if variant=='base' else current).items():(root/path).write_bytes(data)
  name=f'final-all-{variant}-{index}'
  settings={'LABYRINTH_RUNTIME_PERF_SECTIONS':'0','LABYRINTH_RUNTIME_PERF_FOCUSED':'1','LABYRINTH_RUNTIME_PERF_PUBLIC_MENU':'1','LABYRINTH_RUNTIME_PERF_ALL_SURFACES_ONLY':'1','LABYRINTH_RUNTIME_PERF_PRE_BATTLE_ONLY':'0','LABYRINTH_RUNTIME_PERF_REWARD_ONLY':'0'}
  run(name,[sys.executable,'tools/visual_probe_runner.py','tests/runtime_frame_performance_benchmark.gd','--godot',str(out/'godot_windowed_1920.sh'),'--task-id','isolate-card-completion-stalls-'+name,'--no-headless','--display-driver','macos','--audio-driver','Dummy','--rendering-method','mobile','--rendering-driver','metal','--timeout','180','--startup-timeout','12','--min-images','0','--expect-size','1920x1080','--result-manifest',str(out/(name+'.manifest.json'))],settings,'ALL SURFACE PERF RESULT: ')
 for variant in ['base','candidate']:
  for path,data in (original if variant=='base' else current).items():(root/path).write_bytes(data)
  name='final-runtime-'+variant
  settings={'LABYRINTH_RUNTIME_PERF_SECTIONS':'0','LABYRINTH_RUNTIME_PERF_FOCUSED':'0','LABYRINTH_RUNTIME_PERF_PUBLIC_MENU':'1','LABYRINTH_RUNTIME_PERF_ALL_SURFACES_ONLY':'0','LABYRINTH_RUNTIME_PERF_PRE_BATTLE_ONLY':'0','LABYRINTH_RUNTIME_PERF_REWARD_ONLY':'0'}
  run(name,[sys.executable,'tools/visual_probe_runner.py','tests/runtime_frame_performance_benchmark.gd','--godot',str(out/'godot_windowed_1920.sh'),'--task-id','isolate-card-completion-stalls-'+name,'--no-headless','--display-driver','macos','--audio-driver','Dummy','--rendering-method','mobile','--rendering-driver','metal','--timeout','300','--startup-timeout','12','--min-images','0','--expect-size','1920x1080','--result-manifest',str(out/(name+'.manifest.json'))],settings,'RUNTIME FRAME PERF RESULT: ')
finally:
 for path,data in current.items():(root/path).write_bytes(data)
 print('Restored exact complete candidate sources',flush=True)
