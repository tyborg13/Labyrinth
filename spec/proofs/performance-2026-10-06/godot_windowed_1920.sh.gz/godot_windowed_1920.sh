#!/bin/sh
exec /opt/homebrew/bin/godot --windowed --resolution 1920x1080 "$@"
